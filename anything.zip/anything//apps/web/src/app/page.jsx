import { useEffect } from "react";
import { Droplets } from "lucide-react";

export default function SplashPage() {
  useEffect(() => {
    const timer = setTimeout(() => {
      if (typeof window !== "undefined") {
        window.location.href = "/dashboard";
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E8E7D] via-[#2DA890] to-[#6DB89D] flex flex-col items-center justify-center p-6">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-32 right-20 w-96 h-96 bg-[#4DD0B1]/20 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
      </div>

      <div className="relative text-center">
        <Droplets
          size={120}
          className="text-white mx-auto mb-8 animate-bounce"
        />
        <div className="text-5xl md:text-6xl font-bold mb-4">
          <span className="text-white">Aquamind</span>
          <span className="text-[#B5D16A]"> & Nexus</span>
        </div>
        <p className="text-white/90 text-xl">Water Sustainability for Rwanda</p>
      </div>
    </div>
  );
}
